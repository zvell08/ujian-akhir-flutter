package com.example.ujian_akhir

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
