import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:open_file/open_file.dart';

class ResultPage extends StatefulWidget {
  final int studentId;

  ResultPage({required this.studentId});

  @override
  _ResultPageState createState() => _ResultPageState();
}

class _ResultPageState extends State<ResultPage> {
  Map<String, dynamic>? studentData;
  List<Map<String, dynamic>> results = [];
  int? totalNilaiAkhir;

  @override
  void initState() {
    super.initState();
    _fetchResultData();
  }

  Future<void> _fetchResultData() async {
    final String apiUrl = "https://api.artqtion.com/api/gethasil/${widget.studentId}";

    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      Map<String, dynamic> data = jsonDecode(response.body);
      setState(() {
        studentData = data['student'];
        results = List<Map<String, dynamic>>.from(data['results']);
        totalNilaiAkhir = data['total_nilai_akhir']?.toInt(); // Convert to int
      });
    } else {
      print("Failed to fetch result data with status code ${response.statusCode}");
    }
  }

  Future<void> _createPDF(String teacher, String student, double nilaiHarian, double nilaiUTS, double nilaiUAS, double totalKalkulasi) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          return [
            pw.Container(
              color: PdfColors.red800,
              alignment: pw.Alignment.center,
              width: double.infinity,
              child: pw.Text(
                "Student Results",
                style: pw.TextStyle(
                  fontSize: 50,
                  fontWeight: pw.FontWeight.bold,
                  color: PdfColors.white,
                ),
              ),
            ),
            pw.SizedBox(height: 20),
            pw.Text('Student Name: $student'),
            pw.Text('Teacher: $teacher'),
            pw.SizedBox(height: 20),
            pw.Text('Results:'),
            pw.SizedBox(height: 10),
            pw.Table.fromTextArray(
              context: context,
              data: <List<String>>[
                ['Exam', 'Score'],
                ['Harian', nilaiHarian.toString()],
                ['UTS', nilaiUTS.toString()],
                ['UAS', nilaiUAS.toString()],
              ],
            ),
            pw.SizedBox(height: 20),
            pw.Text('Final Exam'),
            pw.Table.fromTextArray(
              context: context,
              data: <List<String>>[
                ['Total Nilai Akhir', totalKalkulasi.toString()],
              ],
            ),
          ];
        },
      ),
    );

    // Save PDF
    final output = await getTemporaryDirectory();
    final file = File("${output.path}/receipt.pdf");
    await file.writeAsBytes(await pdf.save());

    // Display a SnackBar to inform the user that the PDF is saved.
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('PDF saved successfully.'),
      duration: Duration(seconds: 2),
    ));
  }

  Future<void> saveAndOpenPDF(String teacher, String student, double nilaiHarian, double nilaiUTS, double nilaiUAS, double totalKalkulasi) async {
    await _createPDF(teacher, student, nilaiHarian, nilaiUTS, nilaiUAS, totalKalkulasi);

    // Mendapatkan path dari direktori aplikasi
    final output = await getTemporaryDirectory();
    final file = File("${output.path}/receipt.pdf");

    // Open the PDF file using the open_file package
    OpenFile.open(file.path);
  }

  @override
  Widget build(BuildContext context) {
    // ... (Widget build implementation)
  }
}

void main() {
  runApp(MaterialApp(
    home: ResultPage(studentId: 1), // Replace with the actual student ID
  ));
}
