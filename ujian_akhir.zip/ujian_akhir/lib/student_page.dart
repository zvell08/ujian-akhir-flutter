import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'result_page.dart'; // Import halaman ResultPage

class StudentPage extends StatefulWidget {
  @override
  _StudentPageState createState() => _StudentPageState();
}

class _StudentPageState extends State<StudentPage> {
  List<Map<String, dynamic>> students = [];

  @override
  void initState() {
    super.initState();
    _fetchStudents();
  }

  Future<void> _fetchStudents() async {
    final String apiUrl = "https://api.artqtion.com/api/getstudent";

    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      Map<String, dynamic> data = jsonDecode(response.body);
      if (data.containsKey('students') && data['students'] is List) {
        setState(() {
          students = List<Map<String, dynamic>>.from(data['students']);
        });
      }
    } else {
      // Handle error jika respons tidak berhasil (kode selain 200)
      print("Failed to fetch students with status code ${response.statusCode}");
    }
  }

  // Fungsi untuk navigasi ke halaman ResultPage dengan mengirim ID siswa
  void _navigateToResultPage(int studentId) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ResultPage(studentId: studentId),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Student List"),
      ),
      body: ListView.builder(
        itemCount: students.length,
        itemBuilder: (context, index) {
          return Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30.0),
            ),
            margin: EdgeInsets.all(10.0),
            child: ListTile(
              // Menambahkan GestureDetector untuk menangani ketika ListTile diklik
              onTap: () {
                _navigateToResultPage(students[index]['id']);
              },
              title: Text("ID: ${students[index]['id']}"),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Name: ${students[index]['student']}"),
                  Text("Class: ${students[index]['kelas']}"),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: StudentPage(),
  ));
}
